#include "encode.h"
#include "FreeRTOS.h"
#include "task.h"
#include "pwm_motor.h"

// Function to control motor speed during encoding
void motorControlTask(void *pvParameters) {
    while(1) {
        // Example: Adjust motor speed while encoding
        setPWMSpeed(50);  // Set PWM to 50% during encoding
        vTaskDelay(1000 / portTICK_PERIOD_MS); // Delay for 1 second
    }
}

// Function for encoding the message with FreeRTOS task handling
void encodeMessageTask(void *pvParameters) {
    Image *image = (Image *) pvParameters;
    const char *message = "Hello, this is a secret message!";
    
    // Perform LSB encoding
    encodeMessage(image, message);
    
    // Save encoded image
    saveImage("output_image.bmp", image);

    // Send real-time updates through serial communication
    sendSerialMessage("Encoding done. Image saved as output_image.bmp.\n");
    
    // Stop motor after encoding
    setPWMSpeed(0);
    vTaskDelete(NULL); // End the task
}

// Function for decoding the message with FreeRTOS task handling
void decodeMessageTask(void *pvParameters) {
    Image *image = (Image *) pvParameters;
    
    // Decode the message
    char *decodedMessage = decodeMessage(image);
    
    // Send decoded message through serial communication
    sendSerialMessage("Decoded Message: ");
    sendSerialMessage(decodedMessage);

    vTaskDelete(NULL); // End the task
}

// Main function for the FreeRTOS project
int main() {
    // Load the image
    Image *image = loadImage("beautiful_image.bmp");
    
    // Create FreeRTOS tasks for encoding and motor control
    xTaskCreate(encodeMessageTask, "EncodeTask", 1000, (void *) image, 1, NULL);
    xTaskCreate(motorControlTask, "MotorTask", 1000, NULL, 1, NULL);
    
    // Start the FreeRTOS scheduler
    vTaskStartScheduler();

    return 0;
}
