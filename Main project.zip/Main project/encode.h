#ifndef ENCODE_H
#define ENCODE_H

#include "common.h"
#include "types.h"

// Function prototypes for encoding/decoding with FreeRTOS
void encodeMessage(Image* image, const char* message);
char* decodeMessage(const Image* image);
Image* loadImage(const char* filename);
void saveImage(const char* filename, const Image* image);
void freeImage(Image* image);

// FreeRTOS task function prototypes
void encodeMessageTask(void *pvParameters);
void decodeMessageTask(void *pvParameters);
void motorControlTask(void *pvParameters);

#endif // ENCODE_H
