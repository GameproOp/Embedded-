#include "encode.h"
#include "common.h"

// Main function for running the encoding and motor control tests
int main() {
    // Load the BMP image
    Image *image = loadImage("beautiful_image.bmp");

    if (image == NULL) {
        printf("Failed to load image. Ensure the BMP image is in the correct format.\n");
        return 1;
    }

    // Create FreeRTOS tasks for encoding the message and motor control
    xTaskCreate(encodeMessageTask, "EncodeTask", 1000, (void *) image, 1, NULL);
    xTaskCreate(motorControlTask, "MotorTask", 1000, NULL, 1, NULL);

    // Start the FreeRTOS scheduler
    vTaskStartScheduler();

    // Once FreeRTOS starts, the program will continue based on task scheduling
    return 0;
}
