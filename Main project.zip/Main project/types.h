#ifndef TYPES_H
#define TYPES_H

// Pixel structure to hold RGB values
typedef struct {
    uint8_t r;  // Red channel
    uint8_t g;  // Green channel
    uint8_t b;  // Blue channel
} Pixel;

// Image structure to hold pixel data and dimensions
typedef struct {
    Pixel* pixels;  // Array of pixels
    int width;      // Image width in pixels
    int height;     // Image height in pixels
} Image;

#endif // TYPES_H
